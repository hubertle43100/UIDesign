//
//  NewsAPIApp.swift
//  NewsAPI
//
//  Created by Tunde on 08/02/2021.
//

import SwiftUI

@main
struct NewsAPIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
