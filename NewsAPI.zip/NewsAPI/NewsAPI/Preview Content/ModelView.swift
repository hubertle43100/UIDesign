//
//  ModelView.swift
//  NewsAPI
//
//  Created by Hubert Le on 5/19/22.
//

import Foundation
