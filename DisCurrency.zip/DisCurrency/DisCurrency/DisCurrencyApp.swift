//
//  DisCurrencyApp.swift
//  DisCurrency
//
//  Created by Hubert Le on 4/10/22.
//

import SwiftUI

@main
struct DisCurrencyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
